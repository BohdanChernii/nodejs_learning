module.exports = {
  PORT:5000,
  MONGO_URL:'mongodb://localhost:27017/docker',

  S3_BUCKET_NAME:'bodia-chernii-buket'

}